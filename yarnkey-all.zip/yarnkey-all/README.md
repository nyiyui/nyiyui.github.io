This contains all the files for Yarnkey.

- `./device/data` - scripts for processing data
- `./device/code` - code run on the microcontrollers
- `./eval-webapp` - webapp made for evaluation (e.g. measure typing speed, etc)
- `./render` - generates keymap webpage
